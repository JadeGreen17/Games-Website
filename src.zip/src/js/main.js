(function (window) {
  'use strict';
  var FORM_SELECTOR = '[data-game-comment="form"]';
  var CHECKLIST_SELECTOR = '[data-game-comment="checklist"]';
  var SEVER_URL = 'http://coffeerun-v2-rest-api.herokuapp.com/api/coffeeorders';
  var App = window.App;
  var Game = App.Game;
  var DataStore = App.DataStore;
  var RemoteDataStore = App.RemoteDataStore;
  var FormHandler = App.FormHandler;
  var Validation = App.Validation;
  var CheckList = App.CheckList;
  var remoteDS = new RemoteDataStore(SEVER_URL);
  var myGame = new Game('Tower Defense', new DataStore());
  window.myGame = myGame;
  var checkList = new CheckList(CHECKLIST_SELECTOR);
  checkList.addClickHandler(myGame.deliverComment.bind(myGame));
  var formHandler = new FormHandler(FORM_SELECTOR);

  formHandler.addSubmitHandler(function (data) {
    return myGame.createComment(data)
    .then(function (){
      checkList.addRow(data);
    });
});

  formHandler.addInputHandler(Validation.isCompanyEmail);

  myGame.printComments(checkList.addRow.bind(checkList));

  console.log(formHandler);
})(window);
