(function(window){
  'use strict';
  var App = window.App || {};

  function Game(gameId, db){
    this.gameId = gameId;
    this.db = db;
  }

  Game.prototype.createComment = function (comment) {
    console.log('Adding comment for ' + comment.emailAddress);
    return this.db.add(comment.emailAddress, comment);
  };

  Game.prototype.deliverComment = function (userId) {
    console.log('Delivering comment for ' + userId);
    return this.db.remove(userId);
  };

  Game.prototype.printComments = function (printFn) {
    return this.db.getAll()
    .then(function(comments){
      var userIdArray = Object.keys(comments);

      console.log('Game #' + this.gameId + ' has pending comments:');
      userIdArray.forEach(function (id) {
        console.log(comments[id]);
        if(printFn){
          printFn(comments[id]);
        }
      }.bind(this));
    }.bind(this));
  };

  App.Game = Game;
  window.App = App;
})(window);
